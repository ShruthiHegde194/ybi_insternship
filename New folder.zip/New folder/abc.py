#Movie Recommendation System

# Define a dictionary of movies with their genres and ratings
movies ={
    "The Shawshank Redemption": {"genre": "Drama", "rating": 9.2},
    "The Godfather": {"genre": "Crime", "rating": 9.2},
    "The Dark Knight": {"genre": "Action", "rating": 9.0},
    "12 Angry Men": {"genre": "Drama", "rating": 9.0},
    "Schindler's List": {"genre": "History", "rating": 8.9},
}

# Define a function to get recommendations based on genre
def get_genre_recommendations(genre):
    return [movie for movie, details in movies.items() if details["genre"] == genre]

# Define a function to get recommendations based on rating
def get_rating_recommendations(rating):
    return [movie for movie, details in movies.items() if details["rating"] >= rating]

# Define a function to get personalized recommendations
def get_personalized_recommendations(liked_movies):
    recommended_movies = []
    for movie in liked_movies:
        if movie in movies:
            genre = movies[movie]["genre"]
            rating = movies[movie]["rating"]
            recommended_movies.extend(get_genre_recommendations(genre))
            recommended_movies.extend(get_rating_recommendations(rating))
    return list(set(recommended_movies))  # Remove duplicates

# Define a function to get movie recommendations
def get_movie_recommendations():
    print("Movie Recommendation System")
    print("1. Genre-based recommendations")
    print("2. Rating-based recommendations")
    print("3. Personalized recommendations")
    choice = input("Enter your choice (1/2/3): ")
    
    if choice == "1":
        genre = input("Enter the genre: ")
        print("Recommended movies:", get_genre_recommendations(genre))
    elif choice == "2":
        rating = float(input("Enter the minimum rating: "))
        print("Recommended movies:", get_rating_recommendations(rating))
    elif choice == "3":
        liked_movies = input("Enter the movies you like (comma-separated): ").split(",")
        liked_movies = [movie.strip() for movie in liked_movies]
        print("Recommended movies:", get_personalized_recommendations(liked_movies))
    else:
        print("Invalid choice")

# Run the movie recommendation system
get_movie_recommendations()
